using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using Reqnroll;
using System;


namespace CTCLogin.StepDefinitions
{
    [Binding]
    public class LoginStepDefinitions
    {
        private IWebDriver _driver;
        [BeforeScenario]
        public void Setup()
        {
            _driver = new ChromeDriver();
            _driver.Manage().Window.Maximize();
 

        }

        [Given("I click the login link")]
        public void GivenIClickTheLoginLink()
        {
            _driver.Navigate().GoToUrl("https://practicetestautomation.com/practice-test-login/");

        }

        [When("I enter the Username as {string} and password as {string}")]
        public void WhenIEnterTheUsernameAsAndPasswordAs(string admin, string password)
        {
            _driver.FindElement(By.Id("username")).SendKeys("student");
            _driver.FindElement(By.Id("password")).SendKeys("Password123");
        }

        [When("I click the login button")]
        public void WhenIClickTheLoginButton()
        {
            _driver.FindElement(By.Id("submit")).Click();
        }

        [Then("I should be logged in")]
        public void ThenIShouldBeLoggedIn()

        {
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(10));
            IWebElement messageElement = wait.Until(d => d.FindElement(By.XPath("//strong[contains(text(),'Congratulations')]")));

            string actualMessage = messageElement.Text.Trim();
            string expectedMessage = "Congratulations student. You successfully logged in!";

            Assert.That(actualMessage, Is.EqualTo(expectedMessage),
                $"Expected message '{expectedMessage}' but got '{actualMessage}'");
            Thread.Sleep(1000);
        }
        [AfterScenario]
        public void TearDown()
        {
            _driver.Quit();
        }

    }
}
